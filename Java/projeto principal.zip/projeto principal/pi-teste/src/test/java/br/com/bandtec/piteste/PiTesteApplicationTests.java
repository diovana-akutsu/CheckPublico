package br.com.bandtec.piteste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiTesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
