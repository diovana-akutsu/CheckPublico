package br.com.bandtec.piteste.dominio;

public class Anonimo extends Usavel {


    @Override
    public void comentar() {

    }

    @Override
    public void like() {

    }
}
