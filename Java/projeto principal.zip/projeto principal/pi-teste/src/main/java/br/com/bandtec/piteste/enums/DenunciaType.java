package br.com.bandtec.piteste.enums;

public enum DenunciaType {
    IMAGEM_IMPROPRIA(1),
    LINGUAGEM_IMPROPRIA(2),
    FAKE_NEWS(3),
    SPAM(4),
    OUTROS(5);


    DenunciaType(int i) {
    }
}
