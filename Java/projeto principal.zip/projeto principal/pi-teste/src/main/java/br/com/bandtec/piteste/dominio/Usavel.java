package br.com.bandtec.piteste.dominio;

public abstract class Usavel {

    public abstract void comentar();

    public abstract void like();
}
